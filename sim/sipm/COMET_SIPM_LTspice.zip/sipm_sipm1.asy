Version 4
SymbolType CELL
LINE Normal 0 -40 0 -12
LINE Normal 0 16 0 40
LINE Normal -16 16 16 16
LINE Normal 16 16 0 -12
LINE Normal 0 -12 -16 16
LINE Normal -16 -12 16 -12
LINE Normal 60 -68 24 -36
LINE Normal 24 -36 38 -38
LINE Normal 24 -36 28 -50
LINE Normal 84 -44 48 -12
LINE Normal 48 -12 62 -14
LINE Normal 48 -12 52 -26
WINDOW 0 32 -8 Left 2
WINDOW 3 32 24 Left 2
SYMATTR Prefix X
SYMATTR Value MICROFC60035_BEH NPE={NPE} T0=20n TEMP={TEMP}
SYMATTR Description SiPM onsemi MicroFC-60035 (model)
PIN 0 -40 NONE 0
PINATTR PinName K
PINATTR SpiceOrder 1
PIN 0 40 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 2
