COMET - Bias supply · boost and filter (DWG COMET-PWR-01)
LTspice schematic generated from the COMET system schematic
https://ahmeteminaydin.github.io/comet/

Open it
  1. Extract ALL files into one folder (do not open them from inside the zip).
  2. Open COMET_BIAS.asc in LTspice and press Run.
  3. Click a wire to plot its voltage; right-click a part to change its value.

Files
  COMET_BIAS.asc         the schematic, same circuit and values as the site
  *.asy              symbols for the parts LTspice does not ship
  comet_models.lib   behavioural models (op-amps, comparator, logic, SiPM, ...)

The text block under the schematic is the test bench: it drives the input
ports the same way the site does. The models are simplified stand-ins; see the
comments at the top of comet_models.lib.

Not simulated: U12, L1, D2, C27 (the boost converter is replaced by an ideal regulator at TP7 that holds FB at 1.235 V, plus ripple).
