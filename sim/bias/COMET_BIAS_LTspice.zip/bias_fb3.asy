Version 4
SymbolType CELL
LINE Normal -40 0 -24 0
LINE Normal 24 0 40 0
LINE Normal -24 -10 24 -10
LINE Normal 24 -10 24 10
LINE Normal 24 10 -24 10
LINE Normal -24 10 -24 -10
WINDOW 0 -24 -40 Left 2
WINDOW 3 -24 64 Left 2
SYMATTR Prefix X
SYMATTR Value BEAD_BEH L=1u
SYMATTR Description Ferrite bead
PIN -40 0 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 1
PIN 40 0 NONE 0
PINATTR PinName B
PINATTR SpiceOrder 2
