Version 4
SymbolType CELL
LINE Normal 0 48 -60 48
LINE Normal -60 48 -60 -48
LINE Normal -60 -48 0 -48
LINE Normal 0 -48 18 -44
LINE Normal 18 -44 34 -34
LINE Normal 34 -34 44 -18
LINE Normal 44 -18 48 0
LINE Normal 48 0 44 18
LINE Normal 44 18 34 34
LINE Normal 34 34 18 44
LINE Normal 18 44 0 48
LINE Normal -88 -24 -60 -24
LINE Normal -88 24 -60 24
LINE Normal 48 0 76 0
WINDOW 0 -52 -72 Left 2
WINDOW 3 -52 88 Left 2
SYMATTR Prefix X
SYMATTR Value AND2_LVC_BEH
SYMATTR Description U7 74LVC1G08
PIN -88 -24 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 1
PIN -88 24 NONE 0
PINATTR PinName B
PINATTR SpiceOrder 2
PIN 76 0 NONE 0
PINATTR PinName Y
PINATTR SpiceOrder 3
