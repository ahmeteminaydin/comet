Version 4
SymbolType CELL
LINE Normal -40 0 -16 0
LINE Normal 12 0 40 0
LINE Normal -16 -16 -16 16
LINE Normal -16 16 12 0
LINE Normal 12 0 -16 -16
LINE Normal 20 -22 12 -22
LINE Normal 12 -22 12 22
LINE Normal 12 22 4 22
WINDOW 0 -24 -40 Left 2
WINDOW 3 -24 64 Left 2
SYMATTR Prefix D
SYMATTR Value BAT54
SYMATTR Description Diode BAT54
PIN -40 0 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 1
PIN 40 0 NONE 0
PINATTR PinName B
PINATTR SpiceOrder 2
