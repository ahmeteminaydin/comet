COMET - Pulse stretcher · channel A (DWG COMET-DIG-02)
LTspice schematic generated from the COMET system schematic
https://ahmeteminaydin.github.io/comet/

Open it
  1. Extract ALL files into one folder (do not open them from inside the zip).
  2. Open COMET_STRETCH.asc in LTspice and press Run.
  3. Click a wire to plot its voltage; right-click a part to change its value.

Files
  COMET_STRETCH.asc         the schematic, same circuit and values as the site
  *.asy              symbols for the parts LTspice does not ship
  comet_models.lib   behavioural models (op-amps, comparator, logic, SiPM, ...)

The text block under the schematic is the test bench: it drives the input
ports the same way the site does. The models are simplified stand-ins; see the
comments at the top of comet_models.lib.
